# Class Slides Portal

Students open the site and get the same PDF the teacher taught on the smart board.

## Setup (one time)
1. Create a free account at github.com and a new **Public** repository (e.g. `class-slides`).
2. Upload everything inside this folder (`index.html`, `README.md` and the `slides` folder) with **Add file > Upload files**, then commit.
3. Go to **Settings > Pages**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, and Save.
4. After about a minute the site is live at `https://YOURNAME.github.io/REPO-NAME/`. Share that link with students.

## Every day (teachers)
Open the repo, go into the `slides` folder, click **Add file > Upload files**, and drop in the PDF.
Name files like this: `Maths - Quadratic Equations - 2026-11-10.pdf` (Subject - Title - Date).
Teachers must be added under **Settings > Collaborators** (or share one login).

Note: the repo is public, so do not upload anything private.
