Put the PDF slides in this folder. Name them: Subject - Title - YYYY-MM-DD.pdf
